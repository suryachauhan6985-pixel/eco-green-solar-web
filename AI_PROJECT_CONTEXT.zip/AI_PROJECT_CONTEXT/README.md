# AI Project Context

This folder was generated automatically by **AI Project Context Generator**.

It contains structured Markdown documentation describing the project at
`D:\ERF SOFTWARE - RENDER\eco_green_solar_web`, intended to be pasted or attached as context for
AI assistants (ChatGPT, Claude, Gemini, Qwen, DeepSeek, etc.) so they can
understand the codebase without re-reading every source file.

Generated: 2026-08-08T09:14:32.312Z
Files scanned: 60
Files analyzed in depth: 47

## Contents

- `PROJECT_OVERVIEW.md` — high-level summary
- `PROJECT_STRUCTURE.md` — full folder tree
- `TECH_STACK.md` — detected technologies
- `DATABASE.md` — schema, tables, relationships
- `API.md` — HTTP endpoints
- `MODULES.md` — module relationships / data flow
- `ROUTES.md` — routing detail
- `AUTHENTICATION.md` — auth-related findings
- `DEPENDENCIES.md` — package dependencies
- `SERVICES.md` — service-layer files
- `MIDDLEWARE.md` — middleware files
- `CONFIGURATION.md` — config & environment variables
- `FILE_SUMMARIES.md` — per-file breakdown
- `CHANGELOG.md` — diff since last scan
- `AI_CONTEXT.md` — **the single most important file** — paste this into an AI chat first

> This tool never modifies your source code. It only reads files and writes
> Markdown into this `AI_PROJECT_CONTEXT` folder.
