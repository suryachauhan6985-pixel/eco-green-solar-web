# Authentication

## Auth-Related Files

| File | Purpose |
| --- | --- |
| api/services/passwords.js | Implements business logic as a service layer. |
| api/routes/auth.routes.js | Defines HTTP route handlers (controller/router layer). |
| api/middleware/auth.middleware.js | Implements Express/Koa middleware. |


## Auth-Protected Routes (0)

_None detected._


## Public Routes (88)

| Method | Path | File |
| --- | --- | --- |
| GET | /api/attachments | api/routes/attachments.routes.js |
| POST | /api/attachments | api/routes/attachments.routes.js |
| DELETE | /api/attachments/:id | api/routes/attachments.routes.js |
| GET | /api/attachments/:id/file | api/routes/attachments.routes.js |
| POST | /api/auth/forgot-password | api/routes/auth.routes.js |
| POST | /api/auth/heartbeat | api/routes/auth.routes.js |
| POST | /api/auth/login | api/routes/auth.routes.js |
| POST | /api/auth/logout | api/routes/auth.routes.js |
| POST | /api/auth/register | api/routes/auth.routes.js |
| POST | /api/auth/resend-otp | api/routes/auth.routes.js |
| POST | /api/auth/reset-password | api/routes/auth.routes.js |
| POST | /api/auth/verify-otp | api/routes/auth.routes.js |
| POST | /api/auth/verify-register-otp | api/routes/auth.routes.js |
| GET | /api/backup/download/:fileName | api/routes/backup.routes.js |
| POST | /api/backup/run | api/routes/backup.routes.js |
| GET | /api/backup/status | api/routes/backup.routes.js |
| GET | /api/challan | api/routes/challan.routes.js |
| POST | /api/challan | api/routes/challan.routes.js |
| GET | /api/challan/:id | api/routes/challan.routes.js |
| GET | /api/challan/:id/pdf | api/routes/challan.routes.js |
| GET | /api/dashboard/summary | api/routes/health.js |
| GET | /api/health | api/routes/health.js |
| GET | /api/ledgers | api/routes/ledgers.routes.js |
| POST | /api/ledgers | api/routes/ledgers.routes.js |
| DELETE | /api/ledgers/:id | api/routes/ledgers.routes.js |
| PUT | /api/ledgers/:id | api/routes/ledgers.routes.js |
| GET | /api/ledgers/directory | api/routes/ledgers.routes.js |
| GET | /api/ledgers/shortcodes | api/routes/ledgers.routes.js |
| GET | /api/ledgers/statement | api/routes/ledgers.routes.js |
| GET | /api/lowstock | api/routes/health.js |
| GET | /api/masters/brands | api/routes/masters.routes.js |
| GET | /api/masters/categories | api/routes/masters.routes.js |
| POST | /api/masters/categories | api/routes/masters.routes.js |
| DELETE | /api/masters/categories/:name | api/routes/masters.routes.js |
| PUT | /api/masters/categories/:name/serial-rule | api/routes/masters.routes.js |
| PUT | /api/masters/categories/:name/watt-rule | api/routes/masters.routes.js |
| GET | /api/masters/items | api/routes/masters.routes.js |
| POST | /api/masters/items | api/routes/masters.routes.js |
| PUT | /api/masters/items/:id | api/routes/masters.routes.js |
| DELETE | /api/masters/subtypes | api/routes/masters.routes.js |
| POST | /api/masters/subtypes | api/routes/masters.routes.js |
| PUT | /api/masters/subtypes | api/routes/masters.routes.js |
| GET | /api/masters/subtypes/:category | api/routes/masters.routes.js |
| DELETE | /api/masters/units | api/routes/masters.routes.js |
| GET | /api/masters/units | api/routes/masters.routes.js |
| POST | /api/masters/units | api/routes/masters.routes.js |
| PUT | /api/masters/units | api/routes/masters.routes.js |
| GET | /api/masters/users | api/routes/masters.routes.js |
| POST | /api/masters/users | api/routes/masters.routes.js |
| PUT | /api/masters/users/email | api/routes/masters.routes.js |
| PUT | /api/masters/users/password | api/routes/masters.routes.js |
| DELETE | /api/masters/warehouses | api/routes/masters.routes.js |
| GET | /api/masters/warehouses | api/routes/masters.routes.js |
| POST | /api/masters/warehouses | api/routes/masters.routes.js |
| PUT | /api/masters/warehouses | api/routes/masters.routes.js |
| POST | /api/purchase | api/routes/purchase.routes.js |
| DELETE | /api/purchase/:invoiceNo | api/routes/purchase.routes.js |
| PUT | /api/purchase/:invoiceNo | api/routes/purchase.routes.js |
| GET | /api/purchase/brands/:category | api/routes/purchase.routes.js |
| GET | /api/purchase/check-serials | api/routes/purchase.routes.js |
| GET | /api/purchase/find | api/routes/purchase.routes.js |
| GET | /api/purchase/register | api/routes/purchase.routes.js |
| GET | /api/purchase/wattages | api/routes/purchase.routes.js |
| GET | /api/reports/master | api/routes/reports.routes.js |
| POST | /api/returns | api/routes/sales.routes.js |
| GET | /api/sales/check-line | api/routes/sales.routes.js |
| DELETE | /api/sales/delete/:orderNo | api/routes/sales.routes.js |
| POST | /api/sales/dispatch | api/routes/sales.routes.js |
| GET | /api/sales/find/:term | api/routes/sales.routes.js |
| PUT | /api/sales/modify/:orderNo | api/routes/sales.routes.js |
| GET | /api/sales/register | api/routes/sales.routes.js |
| GET | /api/sales/types | api/routes/sales.routes.js |
| GET | /api/scansheet/sheets | api/routes/scansheet.routes.js |
| POST | /api/scansheet/sheets | api/routes/scansheet.routes.js |
| DELETE | /api/scansheet/sheets/:id | api/routes/scansheet.routes.js |
| PUT | /api/scansheet/sheets/:id | api/routes/scansheet.routes.js |
| DELETE | /api/scansheet/sheets/:id/entries | api/routes/scansheet.routes.js |
| GET | /api/scansheet/sheets/:id/entries | api/routes/scansheet.routes.js |
| POST | /api/scansheet/sheets/:id/entries | api/routes/scansheet.routes.js |
| DELETE | /api/scansheet/sheets/:id/entries/:entryId | api/routes/scansheet.routes.js |
| PUT | /api/scansheet/sheets/:id/entries/renumber | api/routes/scansheet.routes.js |
| GET | /api/sessions/live | api/routes/auth.routes.js |
| POST | /api/stockassign | api/routes/stockassign.routes.js |
| GET | /api/stockassign/available | api/routes/stockassign.routes.js |
| GET | /api/stockassign/lines/:reference | api/routes/stockassign.routes.js |
| GET | /api/stockassign/register | api/routes/stockassign.routes.js |
| POST | /api/stockassign/release-customer | api/routes/stockassign.routes.js |
| POST | /api/stockassign/release-firm | api/routes/stockassign.routes.js |

